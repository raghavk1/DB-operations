const mongoose = require('mongoose');
const express = require('express')
const app = express()
const port = 3000
const bodyParser = require('body-parser');
app.use(bodyParser.json()); // Parse JSON request bodies
app.use(bodyParser.urlencoded({ extended: true })); 

main().catch(err => console.log(err));
async function main() {
  await mongoose.connect('mongodb://127.0.0.1:27017/newdb');
  console.log('connected')
}

const productScehma=new mongoose.Schema({
    name:String,
    price:Number,   
    description:String,
    rating: Number,
})
const Product=mongoose.model('Product',productScehma)



app.post('/', function(req, res) {
        const p1=new Product(req.body);
        p1.save().then(()=>{console.log('Document Added')}).catch((err)=>{console.log(err)})
        res.status(201).json(req.body)
});

app.get('/', async function(req, res) {
    var product=await Product.find()
    console.log(product)
    res.json(product)
});
app.delete('/:id', async function(req, res) {
  const productId = req.params.id;

  try {
      const deletedProduct = await Product.findByIdAndDelete(productId);
      console.log('Document Deleted:', deletedProduct);
      res.json({ message: 'Document deleted successfully' });
  } catch (err) {
      console.error('Error deleting document:', err);
      res.status(500).json({ error: 'Failed to delete document' });
  }
});
app.put('/:id', async function(req, res) {
  const productId = req.params.id;
  const updatedProductData = req.body;

  try {
      const updatedProduct = await Product.findByIdAndUpdate(productId, updatedProductData, { new: true });
      console.log('Document Updated:', updatedProduct);
      res.json(updatedProduct);
  } catch (err) {
      console.error('Error updating document:', err);
      res.status(500).json({ error: 'Failed to update document' });
  }
});


app.get('/home', async function(req, res) {
  res.send('Home!')
});
app.listen(port, () => console.log(`Listening on port ${port}!`))